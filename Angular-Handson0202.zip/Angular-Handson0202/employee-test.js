"use strict";
exports.__esModule = true;
var EmployeeTest = /** @class */ (function () {
    function EmployeeTest(emp) {
        this.employee = emp;
    }
    EmployeeTest.prototype.display = function () {
        console.log(this.employee);
    };
    return EmployeeTest;
}());
var employee;
employee = {
    id: 1,
    name: "Ramkumar",
    salary: 25000,
    permanent: true,
    department: {
        id: 1,
        name: "cse"
    },
    skill: {
        id: 1,
        name: "Full stack Developer"
    }
};
var emp = new EmployeeTest(employee);
emp.display();
