import { Employee } from "./employee";

class EmployeeTest {
   employee: Employee;

   constructor(emp) {
      this.employee = emp;
   }

   display() {
      console.log(this.employee);
   }
}

var employee: Employee;

employee = {
   id: 1,
   name: "Rohit",
   salary: 25000,
   permanent: true,
   department: {
      id: 1,
      name: "cse",
   },
   skill: {
      id: 1,
      name: "Full stack Developer",
   },
};

var employeeTest = new EmployeeTest(employee);
employeeTest.display();
